# RUNDEAFIX FIRE CE RUN — Android

**Criadora: Thayná Barros**  
Pacote Android: `ce.rundeafix.firecerun`  
Versão: `1.0.0`

Projeto Android com interface visual acessível, treinos, corrida, respiração, vibração e perfil.

## Gerar APK pelo GitHub Actions (sem computador)

1. Crie um repositório no GitHub e envie o conteúdo desta pasta para ele (extraia o ZIP antes de enviar).
2. No repositório, abra a aba **Actions** e habilite workflows, se o GitHub solicitar.
3. Selecione **Gerar APK Android** e toque em **Run workflow** (ou aguarde a execução automática após enviar para `main`).
4. Quando a execução terminar com marca verde, abra a execução e procure **Artifacts**.
5. Baixe `RUNDEAFIX-FIRE-CE-RUN-APK.zip` no celular e extraia para encontrar `app-debug.apk`.
6. Abra o APK no celular e permita a instalação desta fonte, se o Android solicitar. Instale somente o APK gerado pelo seu próprio repositório.

O workflow usa um runner Linux hospedado pelo GitHub, configura Java e Gradle e executa `gradle assembleDebug`; o APK é guardado como artifact por 14 dias. A compilação exige acesso à internet no runner para obter o Android Gradle Plugin e o Android SDK.

## Importante

Este é um APK **debug para testes**, não uma versão pronta para publicação na Google Play. Antes de publicar, será necessário testar o app em aparelhos reais, revisar permissões, privacidade e recursos, e gerar uma versão release assinada/AAB.
